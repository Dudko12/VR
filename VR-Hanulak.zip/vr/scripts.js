//Transition
document.querySelectorAll('.transition-link').forEach(link => {
    link.addEventListener('click', function(e) {
        // Check if the clicked element is a button inside a form
        if (this.tagName === 'BUTTON' && this.type === 'submit') {
            e.preventDefault();  // Prevent the default form submission

            const form = this.closest('form');  // Find the closest form element
            if (form) {
                // Apply the transition effect
                document.body.style.transform = 'translateX(-100%)';

                // Wait for the transition to complete
                setTimeout(() => {
                    form.submit();  // Submit the form programmatically
                }, 500);  // The time should match the CSS transition time
            }
        } else {
            e.preventDefault(); // Prevent default action for regular links
            const href = this.getAttribute('href');  // Get the URL of the link

            // Apply the transition effect
            document.body.style.transform = 'translateX(-100%)';

            // Wait for the transition to complete, then redirect
            setTimeout(() => {
                window.location.href = href;
            }, 500);  // The time should match the CSS transition time
        }
    });
});

//City Input Autocomplete
// Initialize the autocomplete function
function initAutocomplete() {
    // Get the input field by ID
    const input = document.getElementById('cityInput');

    // Initialize Google Places Autocomplete with restriction to cities only
    const autocomplete = new google.maps.places.Autocomplete(input, {
        types: ['(cities)'], // Restrict to cities only
    });

    // Add listener for when a city is selected from the suggestions
    autocomplete.addEventListener('place_changed', function () {
        const place = autocomplete.getPlace();
        if (!place.geometry) {
            console.log("No details available for input: '" + place.name + "'");
            return;
        }
        // Custom handling of the selected place (optional)
        console.log("City selected: ", place.name);
        // Optionally, you could set the selected city in a hidden input field or submit a form
        // document.getElementById('cityName').value = place.name;
    });
}

// Initialize the autocomplete when the DOM content is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    initAutocomplete();
});

//Redirect
// Check if the current page has the id "forgot-password"
if (document.getElementById('redirect')) {
    // Redirect to login_page.php after a 3-second delay
    setTimeout(function() {
        window.location.href = "login_page.php"; // Change this URL if necessary
    }, 2000); // Delay time in milliseconds (3000 ms = 3 seconds)
}

//Show Transition
document.addEventListener('DOMContentLoaded', () => {
    const bodyContent = document.querySelector('body');
    const screenContent = document.querySelector('.screen-1');

    bodyContent.classList.add('show'); // Add class to body
    screenContent.classList.add('show'); // Add class to screen-1
});


//Show Password
const showPasswordCheckbox = document.getElementById('show-password');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirm_password');  // Ensure ID is correct

showPasswordCheckbox.addEventListener('change', function() {
    const type = this.checked ? 'text' : 'password';
    passwordInput.setAttribute('type', type);  // Update New Password field
    confirmPasswordInput.setAttribute('type', type);  // Update Confirm Password field
});





