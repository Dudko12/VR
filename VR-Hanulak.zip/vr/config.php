<?php
// Database credentials
$host = 'localhost';     // Usually localhost
$db   = 'vr';            // Database name
$user = 'root';          // Username
$pass = '';              // No password (null)

// Create a connection
$conn = new mysqli($host, $user, $pass, $db);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
