<?php
// Start the session to use session variables
session_start();

// Include the database configuration file
require 'config.php';

// Function to handle user registration
function register_function($email, $password) {
    global $conn; // Access the database connection

    // Check if the username already exists
    $stmt = $conn->prepare("SELECT * FROM login_data WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return "Username already exists.";
    }

    // Prepare the SQL statement for insertion
    $stmt = $conn->prepare("INSERT INTO login_data (email, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $email, $password);

    // Execute the statement
    if ($stmt->execute()) {
        return "Registration successful!";
    } else {
        return "Error: " . $stmt->error; // Return error if insert fails
    }
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['email'];
    $password = $_POST['password'];

    // Call the registration function and store the result
    $registerMessage = register_function($username, $password);

    // Optionally, you can redirect or display the message
    if ($registerMessage == "Registration successful!") {
        // Redirect to the login page upon successful registration
        header("Location: login_page.php");
        exit();
    } else {
        // Store the error message in the session
        $_SESSION['register_error'] = $registerMessage;
        header("Location: register_page.php"); // Redirect back to the registration page
        exit();
    }
}
?>
