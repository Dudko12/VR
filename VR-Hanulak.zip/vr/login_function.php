<?php
// Start the session to use session variables
session_start();

// Include the database configuration file
require 'config.php';

// Function to handle user login
function login($email, $password) {
    global $conn;  // Access the database connection

    // Prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM login_data WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $email, $password); // Bind parameters

    // Execute the statement
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        // Fetch the user's data (if needed, you can fetch more than email)
        $user = $result->fetch_assoc();
        return $user; // Return user data if login is successful
    }
    return false; // Return false if login fails
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Call the login function
    $user = login($email, $password);
    if ($user) {
        // Successful login - store the user's email in session
        $_SESSION['email'] = $user['email'];

        // Redirect to index.php
        header("Location: index.php");
        exit(); // Ensure no further code is executed after redirection
    } else {
        // Invalid login attempt - set the error message in session
        $_SESSION['login_error'] = "Invalid email or password.";
        header("Location: login_page.php"); // Redirect back to the login page
        exit();
    }
}
?>
