<?php
// Include the config file to connect to the database
global $conn;
include 'config.php';

// Assuming you want to get the email for a specific user
$user_id = 1; // Change this to the appropriate user ID or condition you want to use

// Prepare the SQL statement to prevent SQL injection
$stmt = $conn->prepare("SELECT email FROM login_data WHERE id = ?");
$stmt->bind_param("i", $user_id); // Assuming 'id' is an integer

// Execute the statement
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Check if any email was found
if ($result->num_rows > 0) {
    // Fetch the email
    $row = $result->fetch_assoc();
    echo "Email: " . $row['email'];
} else {
    echo "No email found for user ID: " . $user_id;
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
