<?php
// Include PHPMailer classes
global $conn;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Include the database configuration
require 'config.php';  // This file contains the $conn MySQLi connection

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format");
    }

    // Generate a random reset token
    $token = bin2hex(random_bytes(16)); // 32 characters long token
    $expiry = date('Y-m-d H:i:s', strtotime('+1 hour')); // Token expires in 1 hour

    // Store the token in the database
    $stmt = $conn->prepare('INSERT INTO password_resets (email, token, expiry) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE token = ?, expiry = ?');
    $stmt->bind_param('sssss', $email, $token, $expiry, $token, $expiry);
    $stmt->execute();

    // Send email with the reset token
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'hanulakdavid@gmail.com'; // Replace with your SMTP username
        $mail->Password = 'xatthlfxuxuqkvak'; // Replace with your SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS encryption
        $mail->Port = 587; // Or 465 if using SSL

        // Recipients
        $mail->setFrom('hanulakdavid@gmail.com', 'Virtual Reception');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset Request';
        $mail->Body = "Click <a href='http://localhost/vr/reset_password_page.php?token=$token'>here</a> to reset your password. This link will expire in 1 hour.";

        // Send the email
        $mail->send();
        header("Location: forgot_password_sent_page.php");
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
