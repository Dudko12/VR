<?php
session_start();

function findHotelsByCity($cityName, $apiKey) {
    // Base URL for Google Places API text search
    $url = 'https://maps.googleapis.com/maps/api/place/textsearch/json';

    // Set up parameters for the API request
    $params = [
        'query' => 'Accommodations in ' . $cityName,
        'key' => $apiKey
    ];

    // Build the full URL with query parameters
    $fullUrl = $url . '?' . http_build_query($params);

    // Initialize cURL
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $fullUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification (Not recommended for production)

    // Execute the request
    $response = curl_exec($ch);

    // Check for errors
    if ($response === false) {
        echo 'Curl error: ' . curl_error($ch);
        return null;
    }

    // Decode the JSON response
    $data = json_decode($response, true);

    // Return the API response
    return $data;
}

// Get API key (replace with your actual Google Places API key)
$apiKey = 'AIzaSyBHCAaztWAOwVFS4HcoZcaznKTZZzGGd8o'; // Replace with your Google Places API Key

// Check if a city name was submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['cityName'])) {
    $cityName = htmlspecialchars($_POST['cityName']); // Sanitize input

    // Save city name in the session
    $_SESSION['cityName'] = $cityName;

    // Call the function to get hotel data for the provided city
    $data = findHotelsByCity($cityName, $apiKey);

    // Store the results in the session so they can be accessed on index.php
    $_SESSION['hotelData'] = $data;

    // Redirect back to index.php to display the results
    header('Location: index.php');
    exit();
} else {
    // If no city name is provided, get hotels from a default random city (like New York)
    $randomCities = ['New York', 'San Francisco', 'Seattle', 'Los Angeles', 'Chicago'];
    $randomCity = $randomCities[array_rand($randomCities)];

    // Save the random city name in the session
    $_SESSION['cityName'] = $randomCity;

    // Call the function to get hotel data for the random city
    $data = findHotelsByCity($randomCity, $apiKey);

    // Store the results in the session so they can be accessed on index.php
    $_SESSION['hotelData'] = $data;

    // Redirect back to index.php to display the results
    header('Location: index.php');
    exit();
}
