<?php
// Include the database configuration
global $conn;
require 'config.php';  // This file contains the $conn MySQLi connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $token = $_POST['token'];

    // Validate the password fields
    if ($password !== $confirm_password) {
        die("Passwords do not match.");
    }

    // Validate token and fetch the associated email from the database
    $stmt = $conn->prepare("SELECT email, expiry FROM password_resets WHERE token = ?");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $stmt->bind_result($email, $expiry);
    $stmt->fetch();
    $stmt->close();

    // Check if token is valid and not expired
    if (!$email) {
        die("Invalid token.");
    }
    if (strtotime($expiry) < time()) {
        die("This token has expired.");
    }

    // Update the password in the login_data table without hashing
    $stmt = $conn->prepare("UPDATE login_data SET password = ? WHERE email = ?");
    $stmt->bind_param('ss', $password, $email); // Bind plaintext password
    if ($stmt->execute()) {
        header("Location: successful_password_reset_page.php");
        // Invalidate the token (optional but recommended)
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
        $stmt->bind_param('s', $token);
        $stmt->execute();
    } else {
        echo "Error updating password.";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
